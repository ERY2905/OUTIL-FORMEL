import java.util.Scanner;

public class Main {
    private static final int code=1234;
    private static final int carte=1234;
    public static void main(String[] args) {
        ControleAcce controle = new ControleAcce();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Bienvenue dans le système de contrôle d'accès.");
        boolean continuer = true;

        while (continuer) {
            System.out.println("Options :");
            System.out.println("1. Vérifier accès");
            System.out.println("2. Déclencher alarme");
            System.out.println("3. Quitter");
            System.out.print("Votre choix : ");
            int choix = scanner.nextInt();

            switch (choix) {
                case 1:
                    System.out.print("veillez entrer votre carte : ");
                    int carteValide = scanner.nextInt();
                    System.out.print("veillez entrer votre code : ");
                    int codeCorrect = scanner.nextInt();

                    boolean cav = (carteValide== carte);
                    boolean cov = (codeCorrect== code);
                    controle.verification(cav, cov);
                    break;

                case 2:
                    controle.alarm();
                    System.out.println("Alarme déclenchée !");
                    break;

                case 3:
                    System.out.println("Fermeture du système.");
                    continuer = false;
                    break;

                default:
                    System.out.println("Choix invalide. Veuillez réessayer.");
            }
        }


    }
}