public class Specialisation {
    private boolean carteVerification;
    private boolean codeVerification;

    public Specialisation(boolean carteVerification, boolean codeVerification) {
        this.carteVerification = carteVerification;
        this.codeVerification = codeVerification;
    }



    public boolean accesAccord(){
        return carteVerification&&codeVerification;
    }

    public boolean accesRefuse(){
        return !accesAccord();
    }
}
