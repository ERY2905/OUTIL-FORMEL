class ControleAcce {

        enum Etat {
        EN_ATTENTE, ACCES_ACCORDE, ACCES_REFUSE, ALARME
    }

    private Etat etatActuel;

public ControleAcce() {
    this.etatActuel = Etat.EN_ATTENTE;
}
public void verification(boolean carteValide, boolean codeCorrect) {
    if (carteValide && codeCorrect) {
        etatActuel = Etat.ACCES_ACCORDE;
        System.out.println("Accès accordé.");
    } else {
        etatActuel = Etat.ACCES_REFUSE;

        System.out.println("Accès refusé.");
    }

}
    public void alarm(){
    this.etatActuel=Etat.ALARME;
    }
}
